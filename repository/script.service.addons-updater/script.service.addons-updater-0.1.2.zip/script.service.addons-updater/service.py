# service.py - starting point of the addon

import resources.lib.addons_updater as addons_updater

addons_updater.run()