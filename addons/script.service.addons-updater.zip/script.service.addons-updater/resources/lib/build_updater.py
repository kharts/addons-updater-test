# build_updater.py - module for build updating


import os
import urllib2
import xml.etree.ElementTree as ET
from distutils.version import LooseVersion
import zipfile
import contextlib
import cStringIO
import time
import xbmc
import xbmcgui
from common import *
from userdata_files import update_guisettings


def update_build():
    """
    Update build from server
    :return: None
    """

    server_version = get_server_version()
    if not need_update_build(server_version):
        return

    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create("Installing Update",
                           "Downloading update..."
                           "Please, do not close Kodi window until update "
                           "is finished")
    build_data = download_build_file(progress_dialog)
    if not build_data:
        return
    extract_build(build_data, progress_dialog)
    xbmc.executebuiltin("UpdateLocalAddons()")
    time.sleep(5)
    update_guisettings("special://userdata/guisettings.xml")
    update_local_version(server_version)
    progress_dialog.close()
    success_dialog = xbmcgui.Dialog()
    res = success_dialog.ok("Update installed",
                            "Update " + server_version + " successfully installed",
                            "Kodi will now close to apply the update. "
                            "Please re-launch Kodi after pressing OK")
    xbmc.executebuiltin("Quit()")
    #info("Update " + server_version + " successfully installed")


def download_build_file(progress_dialog):
    """
    Download build file from the server
    :param progress_dialog: for updating percentage
    :type progress_dialog: xbmcgui.DialogProgress
    :return: binary data of the build file
    :rtype: str
    """

    url = this_addon.getSetting("build_file_path")
    try:
        response = urllib2.urlopen(url)
    except Exception, e:
        log_exception(str(e))
        error("Couldn't get build file from the server")
        progress_dialog.close()
        return None
    total_size = float(response.info().getheader('Content-Length').strip())
    debug("total_size {0}".format(total_size))
    bytes_so_far = 0.0
    chunk_size = int(this_addon.getSetting("chunk_size"))
    result = b''
    while True:
        if progress_dialog.iscanceled():
            progress_dialog.close()
            return None
        chunk = response.read(chunk_size)
        if not chunk:
            break
        result += chunk
        bytes_so_far += len(chunk)
        debug(bytes_so_far)
        if total_size:
            percent = int(bytes_so_far / total_size * 100)
            debug(percent)
            if percent:
                progress_dialog.update(percent,
                                       "Installing Update",
                                       "Downloading update..."
                                       "Please, do not close Kodi window "
                                       "until update is finished.")
    return result


def extract_build(build_data, progress_dialog):
    """
    Extract files from build data zip file into
    special://home folder
    :param build_data: binary data of build zip file
    :type build_data: str
    :param progress_dialog: dialog for showing progress percentage
    :type progress_dialog: xbmcgui.DialogProgress
    :return: None
    """

    buf = cStringIO.StringIO(build_data)
    with contextlib.closing(zipfile.ZipFile(buf, "r")) as build_zip:
        home_folder = xbmc.translatePath("special://home")
        names_list = build_zip.namelist()
        total_number = float(len(names_list))
        extracted = 0.0
        for member in names_list:
            debug(member)
            extension = os.path.splitext(member)[1]
            if extension == ".zip":
                debug("member is zip")
                zip_info = build_zip.getinfo(member)
                zip_data = build_zip.read(zip_info)
                zip_buf = cStringIO.StringIO(zip_data)
                with contextlib.closing(zipfile.ZipFile(zip_buf, "r")) as member_zip:
                    member_zip.extractall(home_folder)
            else:
                debug("member is not zip")
                if os.path.basename(member) != ".gitignore":
                    build_zip.extract(member, home_folder)
                else:
                    debug("Ignore member " + member)
            extracted += 1
            percent = int(extracted / total_number * 100)
            if percent:
                  progress_dialog.update(percent,
                                       "Installing Update",
                                       "Extracting files..."
                                       "Please, do not close Kodi window "
                                       "until update is finished.")


def need_update_build(server_version):
    """
    Check if we need to update build from the server
    :param server_version: version number from the server
    :type server_version: str
    :return: True - if we need to update, False - otherwise
    :rtype: bool
    """

    if server_version:
        local_version = get_local_version()
        if not local_version \
            or LooseVersion(server_version) > LooseVersion(local_version):
                question = xbmcgui.Dialog()
                return question.yesno("Update available",
                      "New version (" + server_version + ") is available",
                      "Do you want to install it right now?")
        else:
            return False
    else:
        return False


def get_server_version():
    """
    Get server build version
    :return: server build version
    :rtype: str
    """

    url = this_addon.getSetting("build_number_path")
    try:
        data = urllib2.urlopen(url)
    except Exception, e:
        log_exception(str(e))
        error("Couldn't get build number from the server")
        return ""
    try:
        tree = ET.parse(data)
    except Exceprion, e:
        log_exception(str(e))
        error("Couldn't parse build number file from the server")
        return ""
    root = tree.getroot()
    return root.attrib.get("version", "")


def get_local_version():
    """
    Get local build version from SQLite database
    :return: local build version
    :rtype: str
    """

    db = get_db("build_versions.db")
    cursor = db.cursor()
    cursor.execute("SELECT name FROM sqlite_master "
                   "WHERE type='table' AND name='build_versions';")
    if cursor.fetchone():
        cursor.execute("SELECT version FROM build_versions;")
        res = cursor.fetchone()
        if res:
            return res[0]
        else:
            return ""
    else:
        return ""


def update_local_version(new_version):
    """
    Update local build version in SQLite database
    :return: None
    """

    db = get_db("build_versions.db")
    cursor = db.cursor()
    cursor.execute("SELECT name FROM sqlite_master "
                   "WHERE type='table' AND name='build_versions';")
    if not cursor.fetchone():
        cursor.execute("CREATE TABLE build_versions "
                       "(version text)")
    cursor.execute("DELETE FROM build_versions")
    cursor.execute("INSERT INTO build_versions "
                   "VALUES ('" + new_version + "')")
    db.commit()
    db.close()